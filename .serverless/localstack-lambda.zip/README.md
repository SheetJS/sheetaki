# sheetaki

Spreadsheet CSV conversion function.  Deployed on <https://sheetaki.now.sh>

Examples:

- [https://obamawhitehouse.archives.gov/sites/default/files/omb/budget/fy2014/assets/receipts.xls](https://sheetaki.now.sh/api/data/?url=https://obamawhitehouse.archives.gov/sites/default/files/omb/budget/fy2014/assets/receipts.xls)

